﻿using System;

namespace Lab3_HeritageEtCompagnie
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variables
            Jeu jeu = new Jeu();

            
            Console.ReadLine();
        }
    }
}
