﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab3_HeritageEtCompagnie
{
    class Jeu
    {
        public Jeu()
        {
            Affichage affichage = new Affichage();

            List<Personnage> listPerso = new List<Personnage>();
            Guerrier guer1 = new Guerrier("Bob", 100); // Testing
            


            //Actions
            affichage.grid[guer1.posX, guer1.posY].perso = guer1;
            
            affichage.afficherGrille();
            System.Threading.Thread.Sleep(500);

            affichage.grid[guer1.posX, guer1.posY].perso = null;
            affichage.grid[guer1.posX, guer1.posY +1].perso = guer1;
            affichage.afficherGrille();
            System.Threading.Thread.Sleep(500);


            affichage.grid[guer1.posX, guer1.posY+1].perso = null;
            affichage.grid[guer1.posX+ 1, guer1.posY+1].perso = guer1;
            affichage.afficherGrille();
            System.Threading.Thread.Sleep(500);

            affichage.grid[guer1.posX + 1, guer1.posY + 1].perso = null;
            affichage.grid[guer1.posX + 1, guer1.posY + 2].perso = guer1;
            affichage.afficherGrille();
            System.Threading.Thread.Sleep(500);

            affichage.grid[guer1.posX + 1, guer1.posY + 2].perso = null;
            affichage.grid[guer1.posX + 1, guer1.posY + 3].perso = guer1;
            affichage.afficherGrille();
            System.Threading.Thread.Sleep(500);


        }
    }
}
